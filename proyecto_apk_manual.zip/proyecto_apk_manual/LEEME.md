# Creador de personajes 3D (APK gratis, sin IA ni servidor)

Novedades de esta versión:
- Girar el modelo arrastrando el dedo sobre la vista previa (izquierda/derecha gira, arriba/abajo cambia la altura de la cámara).
- Tipo de cuerpo: normal, delgado, ancho o cabeza grande.
- Prendas extra (2 a la vez, cada una con su color): chamarra, capa, bufanda, corbata, cinturón, muñequeras y cadena dorada.
- Icono de la app.
- Objetos en la mano (micrófono, rosa, trofeo, balón), uno por mano.
- Mis personajes: guarda y carga tus personajes en el celular.
- Poses de piernas: sliders de muslo, pierna y rodilla, 6 poses listas (caminando, sentado, patada...),
  poses propias con ★ y "Bajar cuerpo" para sentado/agachado.
- Playera: estilos (liso, rayas, mitad y mitad, cuadros) con segundo color, texto o número, y
  "Diseño de playera (arrastra)": marca con el dedo el diseño de una playera en una foto y se copia.
  "Usar esta playera en todos" la aplica a todos los personajes.
- Antes: vista previa con textura real (ojos visibles), cuentagotas de colores, poses de brazos, más peinados.

Cómo compilarla en GitHub (celular):
1. En tu repositorio, borra el zip viejo (toca el archivo > menú de tres puntos > Delete file > Commit).
2. Sube este nuevo zip (Add file > Upload files > Commit changes).
3. La compilación arranca sola (pestaña Actions). Al terminar, baja el artefacto app-debug-apk.

Pide Android 10 o más nuevo (minSdk 29).
