# Creador de personajes 3D (APK gratis, sin IA ni servidor)

Novedades de esta versión:
- La vista previa ahora usa la textura real: se ven ojos, cejas, lentes, barba, etc.
- Sacar colores de una foto (cuentagotas): elige piel, pelo, playera, pantalón, zapatos o gorra y toca la foto.
- Poses personalizadas: sliders para hombro y codo de cada brazo, 6 poses listas y poses propias que se guardan (★).
- Más opciones: peinados (afro, cresta, cola), expresión, color de ojos, bigote, audífonos y mochila.
- Nombre del archivo: escribe el nombre del modelo antes de descargar.

Cómo compilarla en GitHub (celular):
1. En tu repositorio, borra el zip viejo (toca el archivo > menú de tres puntos > Delete file > Commit).
2. Sube este nuevo proyecto_apk_manual.zip (Add file > Upload files > Commit changes).
   El nombre del zip debe ser exactamente proyecto_apk_manual.zip.
3. La compilación arranca sola (pestaña Actions). Al terminar, baja el artefacto app-debug-apk.

Pide Android 10 o más nuevo (minSdk 29).
