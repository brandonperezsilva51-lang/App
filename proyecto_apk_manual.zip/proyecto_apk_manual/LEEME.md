# Creador de personajes 3D (APK gratis, sin IA ni servidor)

La app tiene botones para elegir piel, peinado, ropa, lentes, barba y pose (hasta 4 personajes),
muestra el modelo en vivo y guarda un .zip con modelo.fbx y textura.png en Descargas.
No usa internet, ni clave de API, ni servidor.

Cómo compilarla:
1. Abre la carpeta android/ en Android Studio (descargará Gradle).
2. Menú Build > Build Bundle(s) / APK(s) > Build APK(s).
3. La APK queda en android/app/build/outputs/apk/debug/app-debug.apk. Pásala al celular e instálala
   (hay que permitir instalar apps de origen desconocido).
4. Para Play Store: Build > Generate Signed Bundle / APK con tu propia llave de firma.

Pide Android 10 o más nuevo (minSdk 29).
