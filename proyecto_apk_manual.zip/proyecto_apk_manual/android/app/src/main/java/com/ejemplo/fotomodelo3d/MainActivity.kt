package com.ejemplo.fotomodelo3d

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var selector: ValueCallback<Array<Uri>>? = null

    // Puente: la página llama Android.guardar(nombre, base64) para guardar el .zip en Descargas
    inner class Puente {
        @JavascriptInterface
        fun guardar(nombre: String, base64: String) {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val valores = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, nombre)
                put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            }
            val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Guardado en Descargas: $nombre", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.addJavascriptInterface(Puente(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams
            ): Boolean {
                selector?.onReceiveValue(null)
                selector = cb
                return try {
                    startActivityForResult(p.createIntent(), 1); true
                } catch (e: Exception) {
                    selector = null; false
                }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == 1) {
            selector?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data))
            selector = null
        } else super.onActivityResult(requestCode, resultCode, data)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
